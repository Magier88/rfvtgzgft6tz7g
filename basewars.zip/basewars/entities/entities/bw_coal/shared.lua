ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.PrintName = 'Diesel Can'
ENT.Author = 'n00bmobile'
ENT.Category = 'n00bmobile'
ENT.Spawnable = true
ENT.AdminSpawnable = true
--mine
ENT.IsStatus2D = false