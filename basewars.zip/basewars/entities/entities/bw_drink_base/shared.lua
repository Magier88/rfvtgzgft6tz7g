ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.Author = 'n00bmobile'