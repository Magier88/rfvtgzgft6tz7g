ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.PrintName = 'Munitions Crate'
ENT.Author = 'n00bmobile'
ENT.Category = 'n00bmobile'
ENT.Spawnable = true
ENT.AdminSpawnable = true
--[Customizable Values]--
ENT.MaxAdditional = 2
ENT.Cooldown = 45
ENT.WeaponBlacklist = {
	['weapon_frag'] = true,
}
-------------------------